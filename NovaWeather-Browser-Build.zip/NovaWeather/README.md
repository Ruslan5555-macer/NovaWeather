# Nova Weather

Native Android weather application built with Kotlin, Jetpack Compose, Material 3, MVVM, Retrofit, Coroutines and Preferences DataStore.

## What is included

- Dark navy gradient UI inspired by the supplied reference: centered weather glyph and temperature, compact metrics, hourly cards and floating bottom navigation.
- Live current conditions, 24-hour hourly forecast and 7-day forecast from Open-Meteo (no API key).
- Open-Meteo geocoding city search and an in-app favorites list.
- Weather details, weekly view, Celsius/Fahrenheit display, GPS location request and a cached last successful forecast.
- Offline fallback: the last successful response is stored locally and shown when a request fails.
- A deliberately honest map screen. Open-Meteo is a weather-data API, not a map-tile provider, so the app does not fabricate a map or weather overlay.

## Build

1. Install Android Studio (current stable) with Android SDK Platform 35 and JDK 17.
2. Open this `NovaWeather` folder in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Connect an Android 8.0+ device or start an emulator.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

Command line (with Android SDK and Gradle installed):

```bash
gradle assembleDebug
```

## Permissions and privacy

- Internet is used for Open-Meteo forecast and geocoding requests.
- Location permission is requested only after the user taps “Определить по GPS”. The app uses the last known device location and sends coordinates to Open-Meteo to retrieve weather; it does not need continuous background location.
- No API key or account is required.

## Data endpoints

- Forecast: `https://api.open-meteo.com/v1/forecast`
- Geocoding: `https://geocoding-api.open-meteo.com/v1/search`
- API documentation: https://open-meteo.com/en/docs

## Current implementation notes

This is a working source-project foundation, not a claim that every requested production feature is complete. The current build includes live forecasts, search, favorites, local cache, GPS opt-in and the main navigation/views. The following still need implementation before a production release:

- Persistent settings for units, language, time format and notification toggles.
- Real background alert rules and daily notifications using WorkManager (the notification screen currently provides the UI/state only).
- A real map tile provider and precipitation/temperature/cloud overlay; intentionally not faked.
- True 3D weather assets and richer weather particle animations (current weather symbols use platform emoji glyphs).
- Additional localized strings, automated tests, accessibility review and device/API-level QA.

Open-Meteo free-tier terms and attribution requirements should be reviewed before public distribution: https://open-meteo.com/en/terms

## Build from a browser (GitHub Actions)

This repository includes `.github/workflows/android-apk.yml`. To build without installing Android Studio:

1. Create a GitHub account and create a new **public or private** repository named `NovaWeather`.
2. On the repository page choose **Add file → Upload files** and upload the contents of this `NovaWeather` folder (including the hidden `.github` folder).
3. Commit the upload to the `main` branch.
4. Open the repository's **Actions** tab and select **Build Nova Weather APK**.
5. Press **Run workflow** if it has not started automatically, then open the completed run.
6. In **Artifacts**, download `NovaWeather-debug-apk`. Extract the ZIP and install `app-debug.apk` on your Android phone.

The first cloud build may take several minutes. This produces a debug APK for testing, not a signed release APK for publishing.
