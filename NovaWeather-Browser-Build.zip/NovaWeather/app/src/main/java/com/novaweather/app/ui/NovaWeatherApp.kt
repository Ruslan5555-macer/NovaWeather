package com.novaweather.app

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.android.gms.location.LocationServices
import com.novaweather.app.domain.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Ink = Color(0xFF080B19)
private val Panel = Color(0xFF1B2035)
private val Muted = Color(0xFFABB2C7)
private val Blue = Color(0xFF73D9F5)

@Composable
fun NovaWeatherApp(vm: WeatherVm) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) LocationServices.getFusedLocationProviderClient(context).lastLocation.addOnSuccessListener { loc ->
            if (loc != null) vm.choose(Place("Моё местоположение", "", loc.latitude, loc.longitude))
        }
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101629), Ink, Color(0xFF080A16))))) {
        Box(Modifier.size(340.dp).offset(x=130.dp, y=210.dp).blur(95.dp).background(Color(0xFFB66A2D).copy(.18f), CircleShape))
        Box(Modifier.size(280.dp).offset(x=(-130).dp, y=500.dp).blur(100.dp).background(Color(0xFF235C91).copy(.22f), CircleShape))
        Column(Modifier.fillMaxSize()) {
            when (state.selectedTab) {
                "home" -> HomeScreen(state, vm)
                "search" -> SearchScreen(state, vm)
                "alerts" -> AlertsScreen(state, vm)
                "map" -> MapScreen()
                "details" -> DetailsScreen(state)
                "week" -> WeekScreen(state)
                "settings" -> SettingsScreen(state, vm) { locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }
            }
            if (state.selectedTab !in listOf("details", "week", "settings")) BottomBar(state.selectedTab, vm)
        }
    }
}

@Composable private fun HomeScreen(s: UiState, vm: WeatherVm) {
    val w = s.weather
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=22.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) {
            IconButton(onClick={ vm.tab("settings") }) { Icon(Icons.Default.Menu, null, tint=Color.White) }
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Text(s.place.label, color=Color.White, fontSize=17.sp, fontWeight=FontWeight.SemiBold)
                Text(w?.updatedAt ?: "Nova Weather", color=Muted, fontSize=11.sp)
            }
            IconButton(onClick={ vm.tab("week") }) { Icon(Icons.Default.CalendarMonth, null, tint=Color.White) }
        }
        Spacer(Modifier.height(22.dp))
        if (s.loading && w == null) Box(Modifier.fillMaxWidth().height(350.dp), contentAlignment=Alignment.Center) { CircularProgressIndicator(color=Blue) }
        else if (w == null) EmptyWeather(s.error ?: "Погода пока не загружена", vm)
        else {
            Box(Modifier.fillMaxWidth(), contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text(weatherEmoji(w.code, w.isDay), fontSize=104.sp, modifier=Modifier.shadow(26.dp, CircleShape))
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment=Alignment.Top) {
                        Text("${displayTemp(w.temp, s.celsius)}°", color=Color.White, fontSize=76.sp, fontWeight=FontWeight.Light, letterSpacing=(-4).sp)
                        Text(if (s.celsius) "C" else "F", color=Color.White, fontSize=22.sp, modifier=Modifier.padding(top=12.dp))
                    }
                    Text(weatherText(w.code), color=Color.White, fontSize=17.sp, fontWeight=FontWeight.Medium)
                    Text("Ощущается как ${displayTemp(w.feels,s.celsius)}°  ·  ${w.days.firstOrNull()?.let { "${it.min}° / ${it.max}°" } ?: ""}", color=Muted, fontSize=13.sp, modifier=Modifier.padding(top=7.dp))
                }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                Metric(Icons.Default.Air, "Ветер", "${w.wind} ${s.windUnit}")
                Metric(Icons.Default.WaterDrop, "Осадки", "${w.hours.firstOrNull()?.rain ?: 0}%")
                Metric(Icons.Default.WbSunny, "УФ-индекс", "${w.uv.toInt()}")
            }
            Spacer(Modifier.height(26.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text("Почасовой прогноз", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.SemiBold)
                Text("24 часа", color=Blue, fontSize=12.sp)
            }
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(bottom=4.dp)) {
                items(w.hours) { h -> HourCard(h, s.celsius) }
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text("Подробная информация", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.SemiBold)
                TextButton(onClick={ vm.tab("details") }) { Text("Все данные", color=Blue) }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                InfoTile("Влажность", "${w.humidity}%", Icons.Default.Water)
                InfoTile("Давление", "${w.pressure} гПа", Icons.Default.Speed)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                InfoTile("Облачность", "${w.cloud}%", Icons.Default.Cloud)
                InfoTile("Порывы ветра", "${w.gust} км/ч", Icons.Default.Air)
            }
            Spacer(Modifier.height(22.dp))
            Button(onClick={ vm.refresh() }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Panel)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Обновить прогноз") }
        }
        AnimatedVisibility(s.error != null) { Text(s.error.orEmpty(), color=Color(0xFFFFC27A), fontSize=12.sp, modifier=Modifier.padding(vertical=10.dp)) }
        Spacer(Modifier.height(20.dp))
    }
}

private fun displayTemp(c: Int, isC: Boolean) = if (isC) c else (c * 9.0 / 5.0 + 32).toInt()

@Composable private fun Metric(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Column(Modifier.width(100.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Row(verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=Color.White.copy(.9f), modifier=Modifier.size(19.dp)); Spacer(Modifier.width(6.dp)); Text(value,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Medium) }
        Text(label,color=Muted,fontSize=11.sp, modifier=Modifier.padding(top=5.dp))
    }
}
@Composable private fun HourCard(h: HourItem, celsius: Boolean) {
    Column(Modifier.width(82.dp).clip(RoundedCornerShape(20.dp)).background(Brush.verticalGradient(listOf(Color(0xFF252A42).copy(.92f),Color(0xFF171B2D).copy(.92f)))).padding(vertical=14.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Text(if (h.time.length >= 5) h.time.take(5) else h.time,color=Muted,fontSize=11.sp)
        Text(weatherEmoji(h.code),fontSize=28.sp,modifier=Modifier.padding(vertical=10.dp))
        Text("${displayTemp(h.temp,celsius)}°",color=Color.White,fontSize=18.sp,fontWeight=FontWeight.SemiBold)
        Text("${h.rain}%",color=Blue,fontSize=10.sp,modifier=Modifier.padding(top=4.dp))
    }
}
@Composable private fun RowScope.InfoTile(title:String, value:String, icon:androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.weight(1f).clip(RoundedCornerShape(17.dp)).background(Panel.copy(.8f)).padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
        Icon(icon,null,tint=Blue,modifier=Modifier.size(21.dp)); Spacer(Modifier.width(10.dp)); Column { Text(title,color=Muted,fontSize=11.sp); Text(value,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.SemiBold) }
    }
}
@Composable private fun EmptyWeather(message:String, vm:WeatherVm) {
    Column(Modifier.fillMaxWidth().height(370.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Text("🌌",fontSize=65.sp); Text(message,color=Muted,textAlign=TextAlign.Center,modifier=Modifier.padding(18.dp)); Button(onClick={vm.refresh()}) { Text("Повторить") }
    }
}

@Composable private fun SearchScreen(s:UiState, vm:WeatherVm) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Поиск городов",color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value=s.query,onValueChange=vm::search,modifier=Modifier.fillMaxWidth(),placeholder={Text("Город или страна")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(18.dp),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=Color.White,unfocusedTextColor=Color.White,focusedBorderColor=Blue,unfocusedBorderColor=Muted.copy(.4f),cursorColor=Blue))
        Spacer(Modifier.height(16.dp))
        Text(if(s.query.length>=2) "Результаты" else "Избранные города",color=Muted,fontSize=13.sp)
        val list = if(s.query.length>=2) s.results else s.favorites
        if(list.isEmpty()) Text(if(s.query.length>=2) "Ничего не найдено" else "Добавьте город в избранное после поиска",color=Muted,modifier=Modifier.padding(top=24.dp))
        list.forEach { p ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).clickable { vm.choose(p) }.padding(vertical=13.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn,null,tint=Blue); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(p.name,color=Color.White,fontWeight=FontWeight.Medium); Text(p.country,color=Muted,fontSize=12.sp) }
                IconButton(onClick={vm.toggleFavorite(p)}) { Icon(if(p in s.favorites) Icons.Default.Star else Icons.Default.StarBorder,null,tint=Color(0xFFFFC56C)) }
            }; HorizontalDivider(color=Muted.copy(.12f))
        }
    }
}

@Composable private fun DetailsScreen(s:UiState) {
    val w=s.weather
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Header("Подробный прогноз")
        if(w==null) Text("Данные пока недоступны",color=Muted) else {
            Text("${w.temp}° · ${weatherText(w.code)}",color=Color.White,fontSize=27.sp,fontWeight=FontWeight.Bold)
            Text("${w.place.label} · ${w.updatedAt}",color=Muted,fontSize=12.sp)
            Spacer(Modifier.height(18.dp))
            val rows=listOf("Ощущается как" to "${w.feels}°","Влажность" to "${w.humidity}%","Ветер" to "${w.wind} км/ч","Направление ветра" to "${w.windDirection}°","Порывы ветра" to "${w.gust} км/ч","Давление" to "${w.pressure} гПа","Видимость" to "${w.visibility} км","Облачность" to "${w.cloud}%","УФ-индекс" to "${w.uv}","Точка росы" to "${w.dewPoint}°","Осадки сейчас" to "${w.precipitation} мм","Восход солнца" to w.sunrise,"Закат солнца" to w.sunset)
            rows.chunked(2).forEach { pair -> Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.padding(bottom=10.dp)) { pair.forEach { (a,b)-> Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Panel).padding(14.dp)) { Text(a,color=Muted,fontSize=11.sp); Text(b,color=Color.White,fontSize=16.sp,fontWeight=FontWeight.SemiBold) } }; if(pair.size==1) Spacer(Modifier.weight(1f)) } }
        }
    }
}

@Composable private fun WeekScreen(s:UiState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Header("Прогноз на 7 дней")
        val days=s.weather?.days.orEmpty()
        if(days.isEmpty()) Text("Недельный прогноз пока недоступен",color=Muted)
        days.forEachIndexed { i,d -> Row(Modifier.fillMaxWidth().padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1.1f)) { Text(if(i==0) "Сегодня" else runCatching { LocalDate.parse(d.date).format(DateTimeFormatter.ofPattern("EEE",Locale("ru"))).replaceFirstChar { it.uppercase() } }.getOrDefault(d.date),color=Color.White,fontWeight=FontWeight.Medium); Text(d.date,color=Muted,fontSize=11.sp) }
            Text(weatherEmoji(d.code),fontSize=27.sp,modifier=Modifier.weight(.7f),textAlign=TextAlign.Center)
            Text("${d.min}°",color=Muted,modifier=Modifier.weight(.4f),textAlign=TextAlign.End)
            Box(Modifier.weight(1.2f).padding(horizontal=8.dp).height(5.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(Color(0xFF4B75B9),Color(0xFFFFC16C)))))
            Text("${d.max}°",color=Color.White,modifier=Modifier.weight(.4f),textAlign=TextAlign.End)
            Text("${d.rain}%",color=Blue,fontSize=11.sp,modifier=Modifier.weight(.4f),textAlign=TextAlign.End)
        }; HorizontalDivider(color=Muted.copy(.13f)) }
        Spacer(Modifier.height(18.dp)); Text("Восход и закат",color=Color.White,fontWeight=FontWeight.SemiBold,fontSize=18.sp)
        s.weather?.let { Row(Modifier.fillMaxWidth().padding(top=12.dp),horizontalArrangement=Arrangement.SpaceEvenly) { Text("☀  ${it.sunrise}",color=Color.White); Text("☾  ${it.sunset}",color=Color.White) } }
    }
}

@Composable private fun AlertsScreen(s:UiState, vm:WeatherVm) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Header("Уведомления о погоде")
        Text("Управляйте погодными оповещениями. Для доставки уведомлений в фоне потребуется включить разрешение Android.",color=Muted,fontSize=13.sp)
        Spacer(Modifier.height(18.dp))
        listOf("Дождь и осадки","Снегопад","Сильный ветер","Резкое изменение температуры","Ежедневная сводка").forEach { title ->
            Row(Modifier.fillMaxWidth().padding(vertical=14.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title,color=Color.White,fontWeight=FontWeight.Medium); Text("Оповещения для выбранного города",color=Muted,fontSize=11.sp) }; Switch(checked=s.alertsEnabled,onCheckedChange={vm.toggleAlerts()},colors=SwitchDefaults.colors(checkedThumbColor=Ink,checkedTrackColor=Blue)) }
            HorizontalDivider(color=Muted.copy(.13f))
        }
        Text("Сейчас настройки включения сохраняются в состоянии приложения. Автоматические погодные триггеры требуют отдельного фонового планировщика.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=18.dp))
    }
}

@Composable private fun MapScreen() {
    Column(Modifier.fillMaxSize().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Icon(Icons.Default.Map,null,tint=Blue,modifier=Modifier.size(64.dp)); Spacer(Modifier.height(16.dp)); Text("Карта погоды",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Bold)
        Text("В этой сборке карта отключена: Open-Meteo предоставляет прогнозные данные, но не тайлы карты. Nova Weather не показывает фиктивные слои осадков, температуры или облачности.",color=Muted,textAlign=TextAlign.Center,modifier=Modifier.padding(top=12.dp))
        Text("Для настоящей карты нужно подключить поставщика картографических тайлов и слой погодной визуализации.",color=Muted,fontSize=12.sp,textAlign=TextAlign.Center,modifier=Modifier.padding(top=10.dp))
    }
}

@Composable private fun SettingsScreen(s:UiState, vm:WeatherVm, location:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Header("Настройки")
        SettingRow("Единицы температуры",if(s.celsius) "Цельсий (°C)" else "Фаренгейт (°F)",Icons.Default.Thermostat) { vm.toggleTemp() }
        SettingRow("Формат времени",if(s.use24h) "24 часа" else "12 часов",Icons.Default.Schedule) { vm.toggleTime() }
        SettingRow("Местоположение","Определить по GPS",Icons.Default.MyLocation,location)
        SettingRow("Избранные города","${s.favorites.size} сохранено",Icons.Default.LocationCity) { vm.tab("search") }
        SettingRow("Уведомления",if(s.alertsEnabled) "Включены" else "Выключены",Icons.Default.Notifications) { vm.tab("alerts") }
        Spacer(Modifier.height(20.dp)); Text("О приложении",color=Color.White,fontSize=18.sp,fontWeight=FontWeight.SemiBold)
        Text("Nova Weather 1.0.0\nНативное приложение на Kotlin и Jetpack Compose. Погодные данные: Open-Meteo.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=10.dp))
    }
}
@Composable private fun SettingRow(title:String, value:String, icon:androidx.compose.ui.graphics.vector.ImageVector, action:()->Unit) {
    Row(Modifier.fillMaxWidth().clickable { action() }.padding(vertical=15.dp),verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=Blue); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title,color=Color.White,fontWeight=FontWeight.Medium); Text(value,color=Muted,fontSize=11.sp) }; Icon(Icons.Default.ChevronRight,null,tint=Muted) }; HorizontalDivider(color=Muted.copy(.12f))
}
@Composable private fun Header(title:String) { Row(Modifier.fillMaxWidth().padding(bottom=22.dp),verticalAlignment=Alignment.CenterVertically) { Text(title,color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Bold) } }
@Composable private fun BottomBar(selected:String, vm:WeatherVm) {
    Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=10.dp).navigationBarsPadding().clip(RoundedCornerShape(28.dp)).background(Color(0xFF22263B).copy(.96f)).padding(horizontal=10.dp, vertical=8.dp),horizontalArrangement=Arrangement.SpaceAround,verticalAlignment=Alignment.CenterVertically) {
        val tabs=listOf(Triple("home",Icons.Default.Home,"Главная"),Triple("search",Icons.Default.Search,"Поиск"),Triple("alerts",Icons.Default.NotificationsNone,"Уведомления"),Triple("map",Icons.Default.Map,"Карта"))
        tabs.forEach { (id,icon,label) -> Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).clickable { vm.tab(id) }.padding(vertical=5.dp),horizontalAlignment=Alignment.CenterHorizontally) { Icon(icon,null,tint=if(selected==id) Blue else Muted,modifier=Modifier.size(23.dp)); if(selected==id) Text(label,color=Blue,fontSize=9.sp) } }
    }
}
