package com.novaweather.app.domain

import com.novaweather.app.data.*

data class Place(val name: String, val country: String, val lat: Double, val lon: Double) {
    val label get() = listOf(name, country).filter { it.isNotBlank() }.joinToString(", ")
}
data class HourItem(val time: String, val temp: Int, val code: Int, val rain: Int)
data class DayItem(val date: String, val min: Int, val max: Int, val code: Int, val rain: Int)
data class WeatherSnapshot(
    val place: Place, val updatedAt: String, val temp: Int, val feels: Int, val humidity: Int,
    val wind: Int, val windDirection: Int, val gust: Int, val pressure: Int, val cloud: Int,
    val uv: Double, val visibility: Int = 10, val dewPoint: Int, val precipitation: Double,
    val code: Int, val isDay: Boolean, val sunrise: String, val sunset: String,
    val hours: List<HourItem>, val days: List<DayItem>
)
fun weatherText(code: Int): String = when (code) {
    0 -> "Ясно"; 1 -> "Преимущественно ясно"; 2 -> "Переменная облачность"; 3 -> "Пасмурно"
    45, 48 -> "Туман"; 51, 53, 55 -> "Морось"; 56, 57 -> "Ледяная морось"
    61, 63, 65 -> "Дождь"; 66, 67 -> "Ледяной дождь"; 71, 73, 75, 77 -> "Снег"
    80, 81, 82 -> "Ливень"; 85, 86 -> "Снегопад"; 95, 96, 99 -> "Гроза"; else -> "Погодные условия"
}
fun weatherEmoji(code: Int, day: Boolean = true): String = when (code) {
    0 -> if (day) "☀️" else "🌙"; 1, 2 -> if (day) "🌤️" else "☁️"; 3, 45, 48 -> "☁️"
    in 51..67, in 80..82 -> "🌧️"; in 71..77, 85, 86 -> "🌨️"; else -> "⛈️"
}
fun ForecastDto.toSnapshot(place: Place): WeatherSnapshot {
    val c = requireNotNull(current) { "Нет текущих погодных данных" }
    val h = hourly
    val d = daily
    val now = c.time.orEmpty().take(16).replace('T', ' ')
    val hours = (0 until minOf(24, h?.time?.size ?: 0)).map { i ->
        HourItem(h?.time?.getOrNull(i)?.substringAfter('T') ?: "—", h?.temperature_2m?.getOrNull(i)?.toInt() ?: 0,
            h?.weather_code?.getOrNull(i) ?: 0, h?.precipitation_probability?.getOrNull(i) ?: 0)
    }
    val days = (0 until minOf(7, d?.time?.size ?: 0)).map { i ->
        DayItem(d?.time?.getOrNull(i).orEmpty(), d?.temperature_2m_min?.getOrNull(i)?.toInt() ?: 0,
            d?.temperature_2m_max?.getOrNull(i)?.toInt() ?: 0, d?.weather_code?.getOrNull(i) ?: 0,
            d?.precipitation_probability_max?.getOrNull(i) ?: 0)
    }
    val temp = c.temperature_2m ?: 0.0
    WeatherSnapshot(place, now, temp.toInt(), (c.apparent_temperature ?: temp).toInt(), c.relative_humidity_2m ?: 0,
        (c.wind_speed_10m ?: 0.0).toInt(), c.wind_direction_10m ?: 0, (c.wind_gusts_10m ?: 0.0).toInt(),
        (c.surface_pressure ?: 0.0).toInt(), c.cloud_cover ?: 0, d?.uv_index_max?.firstOrNull() ?: 0.0,
        10, (temp - ((100 - (c.relative_humidity_2m ?: 50)) / 5.0)).toInt(), c.precipitation ?: 0.0,
        c.weather_code ?: 0, c.is_day == 1, d?.sunrise?.firstOrNull()?.substringAfter('T') ?: "—",
        d?.sunset?.firstOrNull()?.substringAfter('T') ?: "—", hours, days)
}
