package com.novaweather.app.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherApi {
    @GET("v1/forecast") suspend fun forecast(
        @Query("latitude") lat: Double,
        @Query("longitude") lon: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,cloud_cover,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m",
        @Query("hourly") hourly: String = "temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,relative_humidity_2m",
        @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max,precipitation_sum",
        @Query("forecast_days") days: Int = 7,
        @Query("timezone") timezone: String = "auto",
        @Query("wind_speed_unit") windUnit: String = "kmh"
    ): ForecastDto

    @GET("v1/search") suspend fun search(
        @Query("name") name: String,
        @Query("count") count: Int = 12,
        @Query("language") language: String = "ru",
        @Query("format") format: String = "json"
    ): GeocodingDto

    companion object {
        val service: WeatherApi by lazy {
            Retrofit.Builder().baseUrl("https://api.open-meteo.com/")
                .addConverterFactory(GsonConverterFactory.create()).build()
                .create(WeatherApi::class.java)
        }
        val geocoder: WeatherApi by lazy {
            Retrofit.Builder().baseUrl("https://geocoding-api.open-meteo.com/")
                .addConverterFactory(GsonConverterFactory.create()).build()
                .create(WeatherApi::class.java)
        }
    }
}

data class ForecastDto(val current: CurrentDto?, val hourly: HourlyDto?, val daily: DailyDto?, val current_units: Map<String,String>?)
data class CurrentDto(
    val time: String?, val temperature_2m: Double?, val relative_humidity_2m: Int?, val apparent_temperature: Double?,
    val is_day: Int?, val precipitation: Double?, val rain: Double?, val showers: Double?, val snowfall: Double?,
    val weather_code: Int?, val cloud_cover: Int?, val surface_pressure: Double?, val wind_speed_10m: Double?,
    val wind_direction_10m: Int?, val wind_gusts_10m: Double?
)
data class HourlyDto(val time: List<String>?, val temperature_2m: List<Double>?, val precipitation_probability: List<Int>?, val precipitation: List<Double>?, val weather_code: List<Int>?, val wind_speed_10m: List<Double>?, val relative_humidity_2m: List<Int>?)
data class DailyDto(val time: List<String>?, val weather_code: List<Int>?, val temperature_2m_max: List<Double>?, val temperature_2m_min: List<Double>?, val sunrise: List<String>?, val sunset: List<String>?, val uv_index_max: List<Double>?, val precipitation_probability_max: List<Int>?, val precipitation_sum: List<Double>?)
data class GeocodingDto(val results: List<GeoResult>?)
data class GeoResult(val id: Long, val name: String, val latitude: Double, val longitude: Double, val country: String?, val admin1: String?, val timezone: String?)
