package com.novaweather.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.novaweather.app.domain.*
import kotlinx.coroutines.flow.first

private val Context.store by preferencesDataStore("nova_weather")

class WeatherRepository(private val context: Context) {
    private val gson = Gson()
    private val cacheKey = stringPreferencesKey("last_weather")
    private val favoritesKey = stringPreferencesKey("favorite_places")
    suspend fun weather(place: Place): WeatherSnapshot = WeatherApi.service.forecast(place.lat, place.lon).toSnapshot(place).also {
        context.store.edit { p -> p[cacheKey] = gson.toJson(it) }
    }
    suspend fun cached(): WeatherSnapshot? = runCatching {
        context.store.data.first()[cacheKey]?.let { gson.fromJson(it, WeatherSnapshot::class.java) }
    }.getOrNull()
    suspend fun search(query: String): List<Place> = WeatherApi.geocoder.search(query).results.orEmpty().map {
        Place(it.name, it.country.orEmpty(), it.latitude, it.longitude)
    }
    suspend fun favorites(): List<Place> = runCatching {
        gson.fromJson(context.store.data.first()[favoritesKey] ?: "[]", Array<Place>::class.java).toList()
    }.getOrDefault(emptyList())
    suspend fun saveFavorites(items: List<Place>) { context.store.edit { it[favoritesKey] = gson.toJson(items) } }
}
