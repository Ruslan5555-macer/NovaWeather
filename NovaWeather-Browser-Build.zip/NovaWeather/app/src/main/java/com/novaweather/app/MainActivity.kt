package com.novaweather.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.LocationServices
import com.novaweather.app.data.WeatherRepository
import com.novaweather.app.domain.*
import com.novaweather.app.ui.NovaWeatherApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vm = ViewModelProvider(this, WeatherVm.Factory(WeatherRepository(applicationContext))).get(WeatherVm::class.java)
        setContent { NovaWeatherApp(vm) }
    }
}

data class UiState(
    val place: Place = Place("Москва", "Россия", 55.7558, 37.6173),
    val weather: WeatherSnapshot? = null, val loading: Boolean = false, val error: String? = null,
    val query: String = "", val results: List<Place> = emptyList(), val favorites: List<Place> = emptyList(),
    val selectedTab: String = "home", val celsius: Boolean = true, val windUnit: String = "км/ч",
    val use24h: Boolean = true, val alertsEnabled: Boolean = true
)
class WeatherVm(private val repo: WeatherRepository) : ViewModel() {
    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()
    init { viewModelScope.launch { _state.value = _state.value.copy(favorites = repo.favorites()); refresh() } }
    fun refresh(place: Place = _state.value.place) = viewModelScope.launch {
        _state.value = _state.value.copy(place = place, loading = true, error = null)
        try { _state.value = _state.value.copy(weather = repo.weather(place), loading = false) }
        catch (e: Exception) {
            val cached = repo.cached()
            _state.value = _state.value.copy(weather = cached, loading = false,
                error = if (cached != null) "Нет соединения. Показаны последние сохранённые данные." else "Не удалось загрузить погоду. Проверьте интернет и повторите попытку.")
        }
    }
    fun search(q: String) = viewModelScope.launch {
        _state.value = _state.value.copy(query = q)
        if (q.trim().length < 2) { _state.value = _state.value.copy(results = emptyList()); return@launch }
        runCatching { repo.search(q.trim()) }.onSuccess { _state.value = _state.value.copy(results = it) }
            .onFailure { _state.value = _state.value.copy(error = "Не удалось выполнить поиск городов") }
    }
    fun choose(place: Place) { _state.value = _state.value.copy(selectedTab = "home", query = "", results = emptyList()); refresh(place) }
    fun toggleFavorite(place: Place) = viewModelScope.launch {
        val list = _state.value.favorites.toMutableList()
        if (place in list) list.remove(place) else list.add(place)
        repo.saveFavorites(list); _state.value = _state.value.copy(favorites = list)
    }
    fun tab(value: String) { _state.value = _state.value.copy(selectedTab = value) }
    fun toggleTemp() { _state.value = _state.value.copy(celsius = !_state.value.celsius) }
    fun toggleTime() { _state.value = _state.value.copy(use24h = !_state.value.use24h) }
    fun toggleAlerts() { _state.value = _state.value.copy(alertsEnabled = !_state.value.alertsEnabled) }
    class Factory(private val repo: WeatherRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = WeatherVm(repo) as T
    }
}
